vista login/home
vista pedidos
vista flujo
vista gestion de usuarios

presentación:
diagrama de clases y BD
metodologias o herramientas
codigo
proyecto

investigar hooks de reactjs

18/8 Semana que viene entrega de investigacion sobre reactjs.
25/8 Entrega de Mock-Ups Login, Inicio de desarrollo vista y API por Rol.
01/9 Entrega de desarrollo vista y API rol.
08/9 Entrega Mockups Nuevo pedido y desarrollo de vista y API de Nuevo pedido (privado y publico).
15/9 Entrega parte anterior.
22/9 Entrega de mockups lista pedidos y desarrollo de vista y api de listado pedidos.
29/9 Entrega del anterior.
06/10 Entrega mockups proceso de aprobacion e inicio de desarrollo vista y api.
27/10 Entrega de el anterior 3 semanas de tiempo.
3/11 Entrega mockups gestion de usuarios, desarrollo de vista y api.
10/11 Enmtrega del desarrollo.
17/11 Presentación final.

Recursos Externos:
    BD - Gratuita usr

    Trello - Practicas II

    Git - 

Conceptos para mockups:
    ejemplos de datos
    campos obligatorios
    widgets